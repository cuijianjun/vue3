import{g as t}from"./get-intrinsic-CWn9CxNF.js";var e=t,r=e("%Object.getOwnPropertyDescriptor%",!0);if(r)try{r([],"length")}catch(g){r=null}var n=r;export{n as g};
