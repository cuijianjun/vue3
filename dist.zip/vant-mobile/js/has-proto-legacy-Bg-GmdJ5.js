System.register([],(function(o,t){"use strict";return{execute:function(){var t={__proto__:null,foo:{}},e=Object;o("h",(function(){return{__proto__:t}.foo===t.foo&&!(t instanceof e)}))}}}));
