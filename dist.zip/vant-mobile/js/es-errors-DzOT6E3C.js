var r=Error,a=EvalError,e=RangeError,s=ReferenceError,o=SyntaxError,v=TypeError,E=URIError;export{a as _,s as a,r as e,e as r,o as s,v as t,E as u};
