import{f as a}from"./function-bind-BbkWVFrm.js";var o=Function.prototype.call,r=Object.prototype.hasOwnProperty,t=a,p=t.call(o,r);export{p as h};
