var o={__proto__:null,foo:{}},t=Object,_=function(){return{__proto__:o}.foo===o.foo&&!(o instanceof t)};export{_ as h};
